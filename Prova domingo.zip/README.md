# Sistema Escolar — Caça aos Erros

Erros encontrados no projeto e como foram corrigidos.

## 1. `pom.xml` — H2 com `scope` `test`
- **Errado:** o H2 só existia no classpath dos testes; ao rodar o app não havia driver de banco.
- **Como descobri:** lendo o `pom.xml` e vendo o README mandar rodar com `spring-boot:run` usando o H2.
- **Correção:** `scope` trocado para `runtime`.

## 2. `pom.xml` — faltava o módulo do console H2
- **Errado:** no Spring Boot 4 o `/h2-console` fica no módulo `spring-boot-h2console`, que não estava no projeto (retorna 404).
- **Como descobri:** vi o parent `4.0.5` e pesquisei a modularização do Spring Boot 4.
- **Correção:** adicionada a dependência `spring-boot-h2console`.

## 3. `application.properties` e `application-dev.properties` — perfil errado
- **Errado:** o perfil ativo era `test` e o `application-dev.properties` estava vazio.
- **Como descobri:** `unzip -l` mostrou o arquivo `dev` com 0 bytes.
- **Correção:** perfil ativo `dev`, e o `application-dev.properties` recebeu a configuração do H2.

## 4. `application-test.properties` — `ddl-auto=none`
- **Errado:** com banco em memória e sem script SQL, as tabelas nunca eram criadas.
- **Como descobri:** não existe `schema.sql`, `data.sql` nem migration no projeto.
- **Correção:** `spring.jpa.hibernate.ddl-auto=create-drop`.

## 5. `application-test.properties` — banco `clinicadb`
- **Errado:** nome de banco de outro projeto (clínica) copiado para o sistema escolar.
- **Como descobri:** o nome não combina com o domínio (Professor, Aluno, Matrícula).
- **Correção:** renomeado para `escolardb` (dev) e `escolardb_test` (test).

## 6. `application-test.properties` — `jwt.secret` sem uso
- **Errado:** propriedade de JWT sem Spring Security nem biblioteca JWT, com um segredo exposto no repositório.
- **Como descobri:** o `pom.xml` não tem dependência de segurança e a palavra `jwt` só aparece nessa linha.
- **Correção:** propriedade removida.

## 7. `Professor.java` — `@Id` sem `@GeneratedValue`
- **Errado:** o `id` ficava nulo no cadastro e o `save` falhava.
- **Como descobri:** comparei com `Aluno` e `Matricula`, que usam `@GeneratedValue`.
- **Correção:** adicionado `@GeneratedValue(strategy = GenerationType.IDENTITY)`.

## 8. `Aluno.java` — `ra` recebendo `curso`
- **Errado:** `this.ra = dados.curso();` gravava o curso no RA.
- **Como descobri:** lendo o construtor de `Aluno`.
- **Correção:** `this.ra = dados.ra();`.

## 9. `ProfessorController.java` — rota `/professor`
- **Errado:** a rota estava no singular, diferente do README e dos outros controllers (`/alunos`, `/matriculas`).
- **Como descobri:** o README cita `/professores`, mas o código mapeava `/professor`.
- **Correção:** `@RequestMapping("/professores")`.

## 10. `Matricula.java` — `@OneToOne` com Aluno
- **Errado:** o JPA cria restrição UNIQUE em `aluno_id`, então cada aluno só poderia ter uma matrícula.
- **Como descobri:** pelo modelo do domínio e comparando com `professor`, que é `@ManyToOne`.
- **Correção:** `@ManyToOne`.

## 11. `AlunoController.java` — `PUT` sem `@Transactional`
- **Errado:** a atualização respondia 200 mas não era salva no banco.
- **Como descobri:** comparei o método `atualizar` com o do `ProfessorController`, que tem a anotação.
- **Correção:** adicionado `@Transactional`.

## 12. Três controllers — faltava `@Valid`
- **Errado:** as validações dos DTOs (`@NotBlank`, `@Email`, `@NotNull`) nunca eram executadas.
- **Como descobri:** os DTOs tinham as anotações, mas os `@RequestBody` não tinham `@Valid`.
- **Correção:** `@RequestBody @Valid` em todos os `POST` e `PUT`.

## 13. `AlunoController` e `ProfessorController` — exclusão física
- **Errado:** o `DELETE` apagava o registro, e `exclusaoLogica()` e o campo `ativo` não eram usados; as listagens mostravam inativos.
- **Como descobri:** `exclusaoLogica()` não era chamado em nenhum lugar do projeto.
- **Correção:** `DELETE` faz `ativo = false`; criado `findAllByAtivoTrue` nos repositórios e usado nas listagens.

## 14. `MatriculaController.java` — `getReferenceById`
- **Errado:** id inexistente de aluno ou professor virava erro 500.
- **Como descobri:** analisando o fluxo de `cadastrar` com um id inválido.
- **Correção:** `findById(...).orElseThrow(EntityNotFoundException::new)`, que retorna 404. Aplicado também em `atualizar` e `excluir`.

## 15. `DadosCadastroMatricula.java` — nomes inconsistentes
- **Errado:** `idAluno` e `professorId` seguiam padrões diferentes.
- **Como descobri:** lendo o record.
- **Correção:** padronizado para `alunoId` e `professorId`.

## 16. `DadosAtualizacaoAluno` e `DadosAtualizacaoProfessor` — `id` sem `@NotNull`
- **Errado:** `PUT` sem `id` causava erro 500.
- **Como descobri:** lendo os records de atualização.
- **Correção:** `@NotNull` no `id` (retorna 400 com o `@Valid`).

## 17. Sem tratamento de erros
- **Errado:** não havia `@RestControllerAdvice`; validação e id inexistente geravam erro 500.
- **Como descobri:** busquei `@ExceptionHandler` e `@RestControllerAdvice` no projeto e não existem.
- **Correção:** criado `infra/TratadorDeErros.java` (400 para validação e 404 para não encontrado).

## 18. `MatriculaController.java` — aluno ou professor inativo
- **Errado:** era possível matricular um aluno ou professor já desativado.
- **Como descobri:** consequência da correção do item 13.
- **Correção:** retorna 400 se algum dos dois estiver inativo.

## 19. `AppApplicationTests.java` — perfil não definido
- **Errado:** o teste usava o perfil padrão do `application.properties`.
- **Como descobri:** lendo a classe de teste.
- **Correção:** `@ActiveProfiles("test")`.

## 20. `pom.xml` — limpeza
- **Errado:** `spring-boot-starter` redundante, tags vazias (`<license/>`, `<developer/>`, `<scm>`) e Lombok no jar final.
- **Como descobri:** lendo o `pom.xml`.
- **Correção:** dependência e tags removidas; Lombok excluído no `spring-boot-maven-plugin`.
